#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <iomanip>
#include <ctime>
using namespace std;

#define INF 65535//�ޱ�ʱ��Ȩֵ
#define MAX_VERTEX_NUM 200//��󶥵���
int p[MAX_VERTEX_NUM][MAX_VERTEX_NUM][MAX_VERTEX_NUM];

int CountLines(char *filename)
{
    ifstream ReadFile;
    int n=0;
    string tmp;
    ReadFile.open(filename,ios::in);//ios::in ��ʾ��ֻ���ķ�ʽ��ȡ�ļ�
    if(ReadFile.fail())//�ļ���ʧ��:����0
    {
        return 0;
    }
    else//�ļ�����
    {
        while(getline(ReadFile,tmp,'\n'))
        {
            n++;
        }
        ReadFile.close();
        return n;
    }
}
string ReadLine(char *filename,int line)
{
    int i=0;
    string temp;
    fstream file;
    file.open(filename,ios::in);
    //lines=CountLines(filename);
    if(file.fail())
    {
        cout<<"Error: file is not exist";
    }
    while(getline(file,temp)&&i<line-1)
    {
        i++;
    }
    file.close();
    return temp;
}
vector<string> splitString(const string& s)
{
    vector<string> ans;
    int len = s.length();
    if (len == 0) return ans;
    for (int i = 0; i < len;){
        int pos = s.find(' ', i);
        if (pos != string::npos){
            if (pos == i){//������������Ŀո�
                i = pos + 1;
                continue;
            }
            else{
                string strTemp = s.substr(i, pos - i);
                ans.push_back(strTemp);
                i = pos + 1;
            }
        }
        else{
            string strTemp = s.substr(i, len - i);
            ans.push_back(strTemp);
            break;
        }
    }
    return ans;
}

typedef struct MGraph{
    string vexs[200];//������Ϣ
    int arcs[200][200];//�ڽӾ���
    int vexnum, arcnum;//�������ͱ���
}MGraph;

int LocateVex(MGraph G, string u)//���ض���u��ͼ�е�λ��
{
    for(int i=0; i<G.vexnum; i++)
        if(G.vexs[i]==u)
            return i;
    return -1;
}

int main()
{
    int i, j, k, l, u, v, w, m, n, x, NF_num, source_num, destination_num;
    int lineNum;
    string a;
    std::vector<string> ans;
    int total_cost=0,cost;
    int min, min1, minid;
	bool final[MAX_VERTEX_NUM];
    string S[MAX_VERTEX_NUM], Des[MAX_VERTEX_NUM];	//	���Դ���Ŀ�ĵ�
	int C[MAX_VERTEX_NUM], c[MAX_VERTEX_NUM];		//��ÿ��NF���������,��ÿ���������������
	int STsum[MAX_VERTEX_NUM];  //��ÿ��ST�Ĵ���
	int open[MAX_VERTEX_NUM];
	int A[MAX_VERTEX_NUM][MAX_VERTEX_NUM];
	int times=50;
    MGraph g;

    char filename[]="C:\\Users\\Administrator\\Desktop\\DataSet\\input\\Cogent_D=14.txt";

    lineNum = CountLines(filename);

    a = ReadLine(filename,1);
    ans = splitString(a);
    g.vexnum = atoi(ans[0].c_str());
    g.arcnum = atoi(ans[1].c_str());
    a = ReadLine(filename,2);
    ans = splitString(a);
    for(i=0; i<g.vexnum; i++)
        g.vexs[i] = ans[i];
    for(i=0; i<g.vexnum; i++)
        for(j=0; j<g.vexnum; j++)
            g.arcs[i][j]=INF;
    for(i=3; i<g.arcnum+3; i++){
        a = ReadLine(filename,i);
        ans = splitString(a);
        for(k=0; k<g.arcnum; k++){
            u=LocateVex(g, ans[0]);
            v=LocateVex(g, ans[1]);
            w = atoi(ans[2].c_str());
            g.arcs[u][v] = w;
            g.arcs[v][u] = w;
        }
    }
    a = ReadLine(filename,g.arcnum+3);
    NF_num = atoi(a.c_str());
    a = ReadLine(filename,g.arcnum+4);
    ans = splitString(a);
    source_num = atoi(ans[0].c_str());
    destination_num = atoi(ans[1].c_str());
    a = ReadLine(filename,g.arcnum+5);
    ans = splitString(a);
    for(i=0; i<source_num; i++)
        S[i] = ans[i];
    a = ReadLine(filename,g.arcnum+6);
    ans = splitString(a);
    for(i=0; i<destination_num; i++)
        Des[i] = ans[i];
    cout<<endl;
    clock_t startTime=clock();

    for(x=0; x<times; x++)
    {
        srand((unsigned)time(NULL));
        for(i=1; i<=NF_num; i++)
            C[i]=rand()%6+5;
        srand((unsigned)time(NULL));
        for(i=0; i<g.vexnum; i++)
            c[i]=rand()%10+40;
        srand((unsigned)time(NULL));
        for(i=0; i<g.vexnum; i++){
            if(g.vexnum > 100)
                open[i]=rand()%10+95;
            else
                open[i]=rand()%10+45;
        }
        for(i=0; i<source_num; i++)
            STsum[i] = 0;
        for(i=0; i<g.vexnum; i++)
            final[i]=false;
        //floyd ���¾���g[][]����¼�������������·��
        for(v=0; v<g.vexnum; v++)
            for(w=0; w<g.vexnum; w++)
            {
                for(u=0; u<g.vexnum; u++)
                    p[v][w][u]=-1;
                if(g.arcs[v][w] < INF)
                {
                    p[v][w][0]=v;
                    p[v][w][1]=w;
                }
            }
        for(u=0; u<g.vexnum; u++)
            for(v=0; v<g.vexnum; v++)
                for(w=0; w<g.vexnum; w++)
                    if(g.arcs[v][u] < INF && g.arcs[u][w] < INF && g.arcs[v][u]+g.arcs[u][w] < g.arcs[v][w])
                    {
                        //����D
                        g.arcs[v][w]=g.arcs[v][u]+g.arcs[u][w];
                        for(i=0; i<g.vexnum; i++)
                        {
                            if(p[v][u][i]!=-1)
                                p[v][w][i]=p[v][u][i];
                            else
                                break;
                        }
                        for(j=1; j<g.vexnum; j++)//ע�⣺����j��1��ʼ�����Ǵ�0��ʼ����Ϊ��v��u��·�����һ��������u, ����u��w��·����һ��������u��ֻ���ӡuһ�μ��ɡ�
                        {
                            if(p[u][w][j]!=-1)
                                p[v][w][i++]=p[u][w][j];
                            else
                                break;
                        }
                    }
        //�Խ����ϵ�ֵΪ0
        for(i=0; i<g.vexnum; i++)
            for(j=0; j<g.vexnum; j++)
                if(i == j)  g.arcs[i][j]=INF;

        //���ȣ�������Դ�ڵ�ֱ���һ��ST,ȡ���д�����С��ST��
        for(k=0; k<source_num; k++)    //ȡ��һ��Դ�������Ŀ�ĵ������ȫͼ
        {
            A[0][0]=g.arcs[k][k];
            for(i=1,m=g.vexnum-destination_num; m<g.vexnum; i++,m++)
            {
                A[0][i] = g.arcs[k][m];
                A[i][0] = g.arcs[m][k];
            }
            for(i=1,m=g.vexnum-destination_num; m<g.vexnum; i++,m++)
                for(j=1,n=g.vexnum-destination_num; n<g.vexnum; j++,n++)
                {
                    A[i][j] = g.arcs[m][n];
                    A[j][i] = g.arcs[n][m];
                }
            int lowcost[MAX_VERTEX_NUM];/* mst[i]��¼��Ӧlowcost[i]����㣬��mst[i]=0ʱ��ʾ���i���������� */
            int mst[MAX_VERTEX_NUM];
            for(i = 1; i < destination_num+1; i++)
            {
                lowcost[i] = A[0][i];
                mst[i] = 0;
            }
            mst[0] = 0;
            for(i = 1; i < destination_num+1; i++)
            {
                min = INF;
                minid = 0;
                for(j = 1; j < destination_num+1; j++)
                {
                    if (lowcost[j] < min && lowcost[j] != 0)
                    {
                        min = lowcost[j];
                        minid = j;
                    }
                }
                STsum[k] += min;
                lowcost[minid] = 0;
                for(j = 1; j < destination_num+1; j++)
                {
                    if(A[minid][j] < lowcost[j])
                    {
                        lowcost[j] = A[minid][j];
                        mst[j] = minid;
                    }
                }
            }
        }
        cost=INF;
        for(i=0; i<source_num; i++)
        {
            if(cost>STsum[i])
            {
                cost=STsum[i];
                k=i;
            }
        }
        final[k]=true;
        l=1;
        while(l<=NF_num)
        {
            min1=INF;
            for(i=0; i<g.vexnum-destination_num; i++)
            {
                if(!final[i] && min1>g.arcs[k][i] && c[i]>=C[l])
                {
                    min1 = g.arcs[k][i];
                    j=i;
                }
            }
            k=j;
            cost += open[k]+min1*2;
            final[k]=true;
            l++;
        }
        cout<<"The "<<x+1<<"th cost is "<<cost<<endl;
        total_cost += cost;
    }
    total_cost = total_cost/times;
    cout<<"The total cost is: "<<total_cost<<endl;
    clock_t endTime=clock();
    cout<<"The run time is:"<<endTime-startTime<<"ms"<<endl;
  	return 0;
}
